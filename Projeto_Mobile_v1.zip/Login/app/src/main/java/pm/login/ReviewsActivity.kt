package pm.login

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.json.JSONObject

class ReviewsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reviews)

        val textView = findViewById<TextView>(R.id.textViewReviews)
        val url = "https://esan-tesp-ds-paw.web.ua.pt/tesp-ds-g35/api/reviews.php"
        val queue = Volley.newRequestQueue(this)

        // Requisição para obter as críticas
        val stringRequest = StringRequest(url, { response ->
            textView.text = parseReviews(response)
        }, { error ->
            textView.text = "Erro ao carregar as críticas: ${error.message}"
        })
        queue.add(stringRequest)

        // Configuração do menu inferior
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigationView.selectedItemId = R.id.nav_reviews // Seleciona a aba atual

        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    // Voltar para a página principal
                    startActivity(Intent(this, UserActivity::class.java))
                    finish() // Finaliza a atividade atual para evitar sobreposição
                    true
                }
                R.id.nav_reviews -> true // Permanece na página atual
                else -> false
            }
        }
    }

    private fun parseReviews(json: String): String {
        val jsonObject = JSONObject(json)
        val reviewsArray = jsonObject.getJSONArray("reviews")
        val result = StringBuilder()

        for (i in 0 until reviewsArray.length()) {
            val review = reviewsArray.getJSONObject(i)
            val movieName = review.getString("movie_name")
            val userId = review.getString("user_id")
            val reviewText = review.getString("review_text")
            val score = review.getString("score")
            val createdAt = review.getString("created_at")

            result.append("Filme: $movieName\n")
                .append("Usuário: $userId\n")
                .append("Crítica: $reviewText\n")
                .append("Pontuação: $score\n")
                .append("Data: $createdAt\n\n")
        }
        return result.toString()
    }
}
