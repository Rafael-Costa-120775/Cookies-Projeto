package pm.login

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import org.json.JSONArray

class ReviewsAdapter(private val reviews: JSONArray) :
    RecyclerView.Adapter<ReviewsAdapter.ReviewViewHolder>() {

    // ViewHolder: Adicionado textViewCreatedAt e corrigido textViewReviewText
    class ReviewViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageViewUser: ImageView = view.findViewById(R.id.imageViewUser)
        val textViewUsername: TextView = view.findViewById(R.id.textViewUsername)
        val textViewReviewText: TextView = view.findViewById(R.id.textViewReviewText)
        val textViewCreatedAt: TextView = view.findViewById(R.id.textViewCreatedAt) // Novo campo
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReviewViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_review, parent, false)
        return ReviewViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReviewViewHolder, position: Int) {
        val review = reviews.getJSONObject(position)
        val username = review.getString("username")
        val userPhoto = review.getString("photo")
        val reviewText = review.getString("review_text")
        val score = review.getString("score")
        val movieName = review.getString("movie_name")
        val createdAt = review.getString("created_at") // Campo de data

        // Configura os valores nos elementos do layout
        holder.textViewUsername.text = username
        holder.textViewReviewText.text =
            "Filme: $movieName\nCrítica: $reviewText\nPontuação: $score"
        holder.textViewCreatedAt.text = createdAt // Exibe a data no lugar de "Nome do Filme"

        // Carrega a imagem do usuário
        Picasso.get()
            .load(userPhoto)
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.error_image)
            .into(holder.imageViewUser)
    }

    override fun getItemCount(): Int {
        return reviews.length()
    }
}
