package pm.login

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class UserActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)

        // Configurar a funcionalidade de logout
        val buttonLogout = findViewById<Button>(R.id.buttonLogout)
        buttonLogout.setOnClickListener {
            doLogout()
        }

        // Configurar o menu inferior
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigation.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    // Já estamos na UserActivity
                    true
                }
                R.id.nav_reviews -> {
                    // Abrir a ReviewsActivity
                    startActivity(Intent(this, ReviewsActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }

    private fun doLogout() {
        // Limpar SharedPreferences para remover o estado de login
        getSharedPreferences("pmLogin", Context.MODE_PRIVATE)
            .edit()
            .clear()
            .apply()

        // Redirecionar o usuário de volta para o MainActivity
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish() // Finaliza a atividade atual
    }
}
