package pm.login

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.json.JSONObject

class ReviewsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reviews)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewReviews)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val url = "https://esan-tesp-ds-paw.web.ua.pt/tesp-ds-g35/api/reviews.php"
        val queue = Volley.newRequestQueue(this)

        // Requisição para obter as críticas
        val stringRequest = StringRequest(url, { response ->
            val reviewsArray = JSONObject(response).getJSONArray("reviews")
            recyclerView.adapter = ReviewsAdapter(reviewsArray)
        }, { error ->
            // Lidar com erro
            // Você pode exibir uma mensagem no log ou na interface
        })

        queue.add(stringRequest)

        // Configuração do menu inferior
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigationView.selectedItemId = R.id.nav_reviews

        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, UserActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_reviews -> true
                else -> false
            }
        }
    }
}
